import React from 'react';

function Newcomp() {
    return (
        <div>
            
            
        </div>
    );
}

export default Newcomp;