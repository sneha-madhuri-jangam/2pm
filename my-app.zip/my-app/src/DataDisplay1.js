import React from 'react';

function DataDisplay1({data}) {
    return (
        <div>
             <div className="mt-4 w-full max-w-xs">
      <h2 className="text-lg font-semibold">Fetched Data</h2>
      <textarea
        className="w-full p-2 border-2 border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mt-2"
        value={data.title}
        readOnly
        placeholder="Fetched title"
      />
      <textarea
        className="w-full p-2 border-2 border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mt-2"
        value={data.body}
        readOnly
        placeholder="Fetched body"
      />
    </div>
            
        </div>
    );
}

export default DataDisplay1;